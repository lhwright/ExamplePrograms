#include "sudoku_solver.h"
#include <iostream>
using namespace std;
sudoku_solver::sudoku_solver() {
}

/* Looks at a possible value in a col for a location and return true or false.
* @param row is the row that the value is in.
* @param col is the col that the value is in.
* @param num is the possible value.
* @return is either True or False.
*/
bool sudoku_solver::col_safe(int row, int col, int num){
	int const numb_val = num;
	for(int i = 0; i < 9; i++){ //looks through each row, col stays the same.
		if ((board[i][col] == numb_val) && (i != row)){
			return false;
		}
	}
	return true;
}

/* Looks at a possible value in a row for a location and return true or false.
* @param row is the row that the value is in.
* @param col is the col that the value is in.
* @param num is the possible value.
* @return is either True or False.
*/
bool sudoku_solver::row_safe(int row, int col, int num){
	int const numb_val = num;
	for(int j = 0; j < 9; j++){ //looks through each col, row stays the same.
		if (board[row][j] == numb_val){
			return false;
		}
	}
	return true;
}

/* this function will return the shift needed to check the
* right box in the puzzle.
* @param position is either the row or col position
*
*/
int sudoku_solver::shift(int const position){
	if(position < 3){
		return 0;
	}
	if((position >= 3) && (position < 6)){
		return 3;
	}
	if(position >= 6){

		return 6;
	}
}

/* Looks at a possible value in a box for a location and return true or false.
* @param row is the row that the value is in.
* @param col is the col that the value is in.
* @param num is the possible value.
* @return is either True or False.
*/
bool sudoku_solver::box_safe(int row, int col, int num){
	int const numb_val = num;
	int const r_shift = shift(row);
	int const c_shift = shift(col);
	for(int i = r_shift; i < (3 + r_shift); i++){ // i is the row that is being looked at
		for(int j = c_shift; j < (3 + c_shift); j++){ // same thing with cols
			if (numb_val == board[i][j]){
				return false;
			}
		}

	}
	return true;
}

/* this function calls three other functions to check the row, 
* col and sector. If they all return true then it will return true. 
* @param row is the row that the value is in.
* @param col is the col that the value is in.
* @param num is the possible value.
* @return is either True or False.
*/
bool sudoku_solver::is_safe(int row, int col, int num){
	if ((col_safe(row, col, num) == true) &&
	   (row_safe(row, col, num) == true) &&
	   (box_safe(row, col, num) == true)){
	   	return true;
	   }
	   
	return false;
}

/*read and store the board
* @param istr is the in stream that takes the input.
*/
void sudoku_solver::read(istream &istr) {
	
	for(int row = 0; row < 9; row++){
		for(int col = 0; col < 9; col++){
			int number;
			number = istr.get() - '0'; // making the char an int
			if(number == -16){ // if it is a space then I want to make it a 0
				number = 0;
			}
			board[row][col] = number;

		}
		istr.get();
	}
}

/*This function will print the puzzle when it is called.
* @param oster is the out stream.
*/
void sudoku_solver::write(ostream &ostr) const {
	for(int i = 0; i < 9; i++){
		for(int j = 0; j < 9; j++){
			ostr << board[i][j];
		}
		ostr << endl;
	}		
}

/* This function will return a bool that is true if the puzzle
* is solved and false if it is not solved. 
* @return is a bool
*/
bool sudoku_solver::solved(){
	for(int row = 0; row < 9; row++){
		for(int col = 0; col < 9; col++){
			if(board[row][col] == 0){
				return false;
			}
		}
	}
	return true;	
}

/* this function will return the row of an empty location. 
* @return row is the row location of a free spot.
*/
int sudoku_solver::get_row(){
	for(int row = 0; row < 9; row++){
		for(int col = 0; col < 9; col++){
			if(board[row][col] == 0)
				return row;
		}
	}
}

/* this function will return the column of an empty location. 
* @return col is the location of a free spot
*/
int sudoku_solver::get_col(){
	for(int row = 0; row < 9; row++){
		for(int col = 0; col < 9; col++){
			if(board[row][col] == 0)
				return col;
		}
	}
}

/* this function is where the solving takes place. It will 
* return true and all the loops will close. 
* It uses an recursive algorithem to solve the problem. If it
* finds a spot where nothing can go then it will back track.
* @return is a bool that that tells if the puzzle is solved or not.
*/
bool sudoku_solver::solve(){
	if (solved() == true){
		return true;
	}
	int row = get_row();
	int col = get_col();
	int num;
	for(int num = 1; num <= 9; num++){
		if (is_safe(row, col, num)){
			board[row][col]= num;
			if (solve()){
				return true;
			}
		board[row][col] = 0;
		}
	}
	return false;
}
	













