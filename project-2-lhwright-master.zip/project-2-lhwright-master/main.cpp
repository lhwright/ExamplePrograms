#include <iostream>
#include "sudoku_solver.h"

using namespace std;

int main() {
    sudoku_solver solver;
    solver.read(cin);
    solver.solve();
    solver.write(cout);
    return 0;
}
