#ifndef MY_SUDOKU_SOLVER
#define MY_SUDOKU_SOLVER

#include <istream>
#include <ostream>
#include <string>

using namespace std;

/* This class is the the board is stored. 
* there are many mamber functions that solve the puzzle.
*/
class sudoku_solver {
    public:
        sudoku_solver();

        void read(istream &istr);
        bool is_safe(int row, int col, int num);
        bool box_safe(int row, int col, int num);
        int shift(int const position);
        bool col_safe(int row, int col, int num);
        bool row_safe(int row, int col, int num);
        void write(ostream &istr) const;
        bool solved();
        int get_row();
        int get_col();

        bool solve();
    private:
    	int board[9][9]; // 9x9 board
};

#endif // MY_SUDOKU_SOLVER
