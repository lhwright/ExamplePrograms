/**
    CS 111 (Mini-)Project 4: Basic BST Methods 
    binary_search_tree.cpp

    @author <your name goes here>
*/
#include "binary_search_tree.h"
#include <iostream>

using namespace std;
binary_search_tree::binary_search_tree() {
    p_root = nullptr;
}
/* deconstructor
*/
binary_search_tree::~binary_search_tree() {
	deallocate(p_root);
}
/* deconstructor helper function.
input: p_node is the root of the tree.
no output
*/
void binary_search_tree::deallocate(node *p_node){
	if (p_node == nullptr)
		return;
	if(p_node -> p_right == nullptr && p_node -> p_left == nullptr){
		delete p_node;
		return;
	}
	deallocate(p_node-> p_left);
	deallocate(p_node-> p_right);
	delete p_node;

	return;
}
/* input is a value that we want to put into our tree.
*/
void binary_search_tree::insert(int x) {
	struct node *p_node = new struct node;
	p_node -> value = x;
	node *p_current = p_root;
	if(p_root == nullptr){
		p_root = p_node;
		return;
	}
	while (p_current != nullptr){

		if (p_current->value > p_node->value){
			if(p_current->p_left == nullptr){
				p_current ->p_left = p_node;
				break;
			}
			p_current = p_current -> p_left;
		}
		else{
			if(p_current->p_right == nullptr){
				p_current ->p_right = p_node;
				break;
			}
			p_current = p_current -> p_right;
		}
	}
}
/* traverses the tree and prints the values in order
*/
void binary_search_tree::print_in_order() const {
	print_in_order_recursive(p_root);
}
/* helper function for print_in_order()
param p_node is the pointer to the root
no function return output
*/
void binary_search_tree::print_in_order_recursive(node *p_node) const {
	if(p_node == nullptr){
		return;
	}
	print_in_order_recursive(p_node-> p_left);
	cout << p_node -> value;
	print_in_order_recursive(p_node-> p_right);
	return;
}
/* function to find how many levels there are.
no input or output
*/
void binary_search_tree::height(){ 
	cout << find_height(p_root)<< endl;
}
/* helper function for height. 
input p_node is the root of tree
output is an integer equal to the number of levels in tree.
*/
int binary_search_tree::find_height(node *p_node){
	if (p_node == nullptr)
		return 0;
	if(p_node -> p_right == nullptr && p_node -> p_left == nullptr){
		return 1;
	}
	int l = find_height(p_node-> p_left);
	int r = find_height(p_node-> p_right);
	if(l > r){
		return l + 1 ;
	}
	else{
		return r + 1;
	}
}








