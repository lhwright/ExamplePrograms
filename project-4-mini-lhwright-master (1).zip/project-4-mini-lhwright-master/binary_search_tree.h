/**
    CS 111 (Mini-)Project 4: Basic BST Methods 
    binary_search_tree.h

    @author <your name goes here>
*/
#ifndef _BST_H_
#define _BST_H_

struct node {
    int   value    = 0;

    node *p_parent = nullptr;
    node *p_left   = nullptr;
    node *p_right  = nullptr;
};

class binary_search_tree {
    public:
        binary_search_tree();
        ~binary_search_tree();

        void insert(int x);
        void print_in_order() const;
        void height();
    private:
        int find_height(node *p_node);
        void deallocate(node *p_node); 
        void print_in_order_recursive(node *p_node) const;
        node *p_root;
};

#endif //_BST_H_
