/**
    CS 111 (Mini-)Project 4: Basic BST Methods 
    main.cpp

    @author <your name goes here>
*/
#include <iostream>
#include "binary_search_tree.h"

using namespace std;
/* function to insert the values in the correct order to make theta log(n) height
param a[] is the array of numbers that we want to add
param start is the starting index
param end is the index of the last value
param my_other_other_list is the list that we are adding the numbers to.
*/
void order_tree(int a[], int start, int end, binary_search_tree &my_other_other_list){
    if(start > end)
        return;

    int mid = (start + end) / 2;
        
    my_other_other_list.insert(a[mid]);
    order_tree(a, start, mid - 1, my_other_other_list);
    order_tree(a, mid + 1, end, my_other_other_list);
}
int main() {
    binary_search_tree my_bst;
    binary_search_tree my_other_bst;
    binary_search_tree my_other_other_bst;

    my_bst.insert(3);
    my_bst.insert(1);
    my_bst.insert(2);
    my_bst.insert(5);
    my_bst.insert(4);
    for(int i = 0; i < 10;i++){
        my_other_bst.insert(i);
    }
    int a[] = {1,2 ,3 ,4 ,5 ,6 ,7 ,8 };
    int n = 7;
    order_tree(a, 0, n, my_other_other_bst);

    //prints out 1 2 3 4 5
    my_bst.print_in_order();
    cout << endl;
    my_bst.height();
    my_other_bst.print_in_order();
    cout << endl;
    my_other_bst.height();
    my_other_other_bst.print_in_order();
    cout << endl;
    my_other_other_bst.height();
    return 0;
}
