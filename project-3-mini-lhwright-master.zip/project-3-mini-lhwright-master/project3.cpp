/**
    CS 111 Mini Project 3: Doubling Experiment 
    main.cpp

    @author <Lucas Wright and Darren Strash>
*/
#include <iostream>
#include <string>
#include <cstring>
#include <ctime>
#include <iomanip>
#include <math.h>

using namespace std;

/**
 *     a 
 *     @param n an input size
 *     @return nothing
 */
void insertion(size_t const n) {
    int size_of_array = 1;
    for(size_t i = 1; i < n + 1; i++){ //adding n elements
    	if(i > size_of_array){
    		size_of_array = size_of_array * 2; // doubling the size of the array
    		for(size_t j = 0; j < n; j++){ // simulate a new array being copied, takes n time
    		}
    	}
    }
}

/**
 *     code that runs in \Theta(n) time, but with a larger constant
 *
 *     @param n an input size
 *     @return nothing
 */
void slower_linear(size_t const n) {
    for(size_t i = 0; i < n; i++){
        for(size_t i = 0; i < 100; i++){
        }
    }
}

/**
 *     code that runs in \Theta(n^2) time.
 *
 *     @param n an input size
 *     @return nothing
 */
void quadratic(size_t const n) {
    for(size_t i = 0; i < n; i++){
        for(size_t i = 0; i < n; i++){
        }
}
}
/**
 *     code that runs in \Theta(log n) time.
 *
 *     @param n an input size
 *     @return nothing
 */
void logarithmic(size_t const n) {
    for(size_t i = 1; i <= n; i = i * 2){
        for(size_t i = 0; i < 10054776; i++){
        } 
    }
}

/**
 *     code that runs in ??? time.
 *
 *     @param n an input size
 *     @return nothing
 */
void mystery(size_t const n) {
    int sum = 0;
    char *p_chars = new char[n+1];
    for (size_t i = 0; i < n; i++) {
        p_chars[i] = 'a';
    }

    p_chars[n] = '\0';

    for (size_t i = 0; i < strlen(p_chars); i++) {
        sum++;
    }
}

/**
 *     compute the time a given function takes, and return it
 *
 *     @param p_func a pointer to a function
 *     @param size the size (number of elements) to pass to the function
 *     @return the time (in milliseconds) the function takes to run
 */
double time(void p_func(size_t const), size_t const size) {
    clock_t start_time = clock();

    (*p_func)(size);

    double const time_in_ms = ((clock() - start_time)*1000.0)/CLOCKS_PER_SEC;

    return time_in_ms;
}

/**
 *     run the linear time experiment
 *
 *     @return nothing
 */
void linear_experiment() {
    cout << setw(15) << "n" << setw(15) << "insertion (ms)"  << endl << flush;
    for (size_t n = 1; n < 10000000000; n*=2) {
        cout << setw(15) << n << flush;
        cout << setw(15) << time(&insertion, n) << endl << flush;
    }
}

/**
 *     run the (slower) linear time experiment
 *
 *     @return nothing
 */
void slower_experiment() {
    cout << setw(15) << "n" << setw(15) << "insertion (ms)" << setw(15) << "slower (ms)" << endl << flush;
    for (size_t n = 1; n < 10000000000; n *= 2) {
        cout << setw(15) << n << flush;
        cout << setw(15) << time(&insertion, n) << flush;
        cout << setw(15) << time(&slower_linear, n) << endl << flush;
    }
}

/**
 *     run the quadratic time experiment
 *
 *     @return nothing
 */
void quadratic_experiment() {
    cout << setw(15) << "n" << setw(15) << "linear (ms)" << setw(17) << "quadratic (ms)" << endl << flush;
    for (size_t n = 1; n < 10000000000; n *= 2) {
        cout << setw(15) << n << flush;
        cout << setw(15) << time(&insertion, n) << flush;
        cout << setw(17) << time(&quadratic, n) << endl << flush;
    }
}

/**
 *     run the log time experiment
 *
 *     @return nothing
 */
void log_experiment() {
    cout << setw(15) << "n" << setw(15) << "linear (ms)" << setw(15) << "log (ms)" << endl << flush;
    for (size_t n = 1; n < 10000000000; n *= 2) {
        cout << setw(15) << n << flush;
        cout << setw(15) << std::fixed << std::setprecision(0) << time(&insertion, n) << flush;
        cout << setw(15) << std::fixed << std::setprecision(4) << time(&logarithmic, n) << endl << flush;
    }
}

/**
 *     run the mystery time experiment
 *
 *     @return nothing
 */
void mystery_experiment() {
    cout << setw(15) << "n" << setw(15) << "mystery (ms)" << endl << flush;
    for (size_t n = 1; n < 10000000000; n *= 2) {
        cout << setw(15) << n << flush;
        cout << setw(15) << time(&mystery, n) << endl << flush;
    }
}

/**
 *     run an experiment specified by its name (as a string)
 *
 *     @param experiment an experiment name (as a string)
 *     @return nothing
 */
void run_experiment(string const &experiment) {

    cout << std::fixed << std::setprecision(2);

    if (experiment == "insertion") {
        linear_experiment();
    } else if (experiment == "slower") {
        slower_experiment();
    } else if (experiment == "quadratic") {
        quadratic_experiment();
    } else if (experiment == "log") {
        log_experiment();
    } else if (experiment == "mystery") {
        mystery_experiment();
    }
}
/**
 *     check that a given string is one of several allowed options
 *
 *     @param argument a string to compare against
 *     @return true if and only if string matched an allowed option
 */
bool validate_input(string const &argument) {
    return argument == "insertion"    || argument == "slower" || 
           argument == "quadratic" || argument == "log" || 
           argument == "mystery";
}

/**
 *     print formatted message illustrating program usage
 *
 *     @return true if and only if string matched an allowed option
 */
void print_usage(char *prog_name) {
    cout << "usage: " << prog_name << " linear | slower | quadratic | log | mystery" << endl << flush;
}

/**
 *     validate command line arguments and run a selected experiment
 *
 *     @param argc the number of command line arguments
 *     @param argv the command line arguments
 *     @return error code, 0 if no error
 */
int main(int argc, char **argv) {

    if (argc != 2) {
        print_usage(argv[0]);
        return 1;
    } else if (!validate_input(argv[1])) {
        cout << "Unknown argument \"" << argv[1] << "\"" << endl << flush;
        print_usage(argv[0]);
        return 1;
    }

    run_experiment(argv[1]);

    return 0;
}
